import { useEffect } from 'react';

export default function ContactNavBridge() {
  useEffect(() => {
    const buttons = document.querySelectorAll('.nav-right .magnetic-btn, .mobile-menu .magnetic-btn');
    buttons.forEach((button) => {
      button.setAttribute('href', '#inquiry');
      button.removeAttribute('target');
      button.removeAttribute('rel');
      const label = button.querySelector('span');
      if (label) label.textContent = 'Get in touch';
    });

    const finalButton = document.querySelector('.final-cta .magnetic-btn');
    if (finalButton) {
      finalButton.setAttribute('href', '#inquiry');
      finalButton.removeAttribute('target');
      finalButton.removeAttribute('rel');
      const label = finalButton.querySelector('span');
      if (label) label.textContent = 'Get in touch';
    }

    const footerBottom = document.querySelector('footer .footer-bottom');
    if (footerBottom && !footerBottom.querySelector('.privacy-footer-link')) {
      const link = document.createElement('a');
      link.className = 'privacy-footer-link';
      link.href = '#privacy';
      link.textContent = 'Privacy';
      footerBottom.appendChild(link);
    }
  }, []);
  return null;
}
