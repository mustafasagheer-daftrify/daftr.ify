import React, { useEffect, useState } from 'react';
import { motion, useMotionValue, useScroll, useSpring, useTransform } from 'framer-motion';
import './motion.css';

export default function MotionLayer() {
  const [intro, setIntro] = useState(true);
  const [mouseReady, setMouseReady] = useState(false);
  const mx = useMotionValue(-100);
  const my = useMotionValue(-100);
  const cx = useSpring(mx, { stiffness: 260, damping: 28, mass: .45 });
  const cy = useSpring(my, { stiffness: 260, damping: 28, mass: .45 });
  const { scrollYProgress } = useScroll();
  const heroOpacity = useTransform(scrollYProgress, [0, .055, .12], [1, 1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, .12], [1, 1.14]);
  const heroY = useTransform(scrollYProgress, [0, .12], [0, -80]);
  const heroBlur = useTransform(scrollYProgress, [0, .08, .12], ['0px', '0px', '7px']);
  const ghostX = useTransform(scrollYProgress, [0, .12], ['-50%', '-43%']);
  const ghostScale = useTransform(scrollYProgress, [0, .12], [1, 1.18]);

  useEffect(() => {
    const timer = window.setTimeout(() => setIntro(false), 2350);
    const move = (e) => { mx.set(e.clientX); my.set(e.clientY); setMouseReady(true); };
    const leave = () => setMouseReady(false);
    window.addEventListener('mousemove', move);
    document.documentElement.addEventListener('mouseleave', leave);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('mousemove', move);
      document.documentElement.removeEventListener('mouseleave', leave);
    };
  }, [mx, my]);

  useEffect(() => {
    document.body.classList.toggle('intro-active', intro);
    return () => document.body.classList.remove('intro-active');
  }, [intro]);

  return <>
    {intro && <motion.div className="intro-sequence" initial={{ opacity: 1 }} animate={{ opacity: 0 }} transition={{ duration: .55, delay: 1.82, ease: [0.76, 0, .24, 1] }}>
      <motion.div className="intro-bloom" initial={{ scale: .04, opacity: .9 }} animate={{ scale: 1, opacity: 0 }} transition={{ duration: 1.75, ease: [0.16, 1, .3, 1] }} />
      <motion.div className="intro-ring" initial={{ scale: .25, opacity: 0 }} animate={{ scale: 1.8, opacity: [0, .8, 0] }} transition={{ duration: 1.65, delay: .12, ease: 'easeOut' }} />
      <div className="intro-brand">
        <div className="intro-overline">AI-ASSISTED DOCUMENT STUDIO</div>
        <div className="intro-word"><motion.span initial={{ y: '110%' }} animate={{ y: 0 }} transition={{ duration: .8, delay: .15, ease: [0.22, 1, .36, 1] }}>DAFTR</motion.span><motion.span className="intro-accent" initial={{ y: '110%' }} animate={{ y: 0 }} transition={{ duration: .8, delay: .21, ease: [0.22, 1, .36, 1] }}>IFY</motion.span></div>
        <motion.div className="intro-line" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: .9, delay: .55, ease: [0.22, 1, .36, 1] }} />
        <motion.div className="intro-caption" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .7, duration: .5 }}>STRUCTURE / SPEED / DETAIL</motion.div>
      </div>
      <motion.div className="intro-index" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .8 }}><span>001</span><i/><span>001</span></motion.div>
    </motion.div>}

    <motion.div className="cinematic-hero-layer" style={{ opacity: heroOpacity, scale: heroScale, y: heroY, filter: heroBlur }}>
      <motion.div className="hero-ghost-word" style={{ x: ghostX, scale: ghostScale }}>DAFTRIFY</motion.div>
      <motion.div className="hero-depth-orb one" />
      <motion.div className="hero-depth-orb two" />
      <div className="hero-film-marker"><i/><span>01 / 05 · DOCUMENT FLOW</span></div>
    </motion.div>

    <motion.div className="scroll-progress" style={{ scaleX: scrollYProgress }} />
    {mouseReady && <motion.div className="cursor-aura" style={{ x: cx, y: cy }} />}
  </>;
}
