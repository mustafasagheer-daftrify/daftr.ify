import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, Check, MapPin, Sparkles } from 'lucide-react';
import './founder.css';

export default function Founder() {
  return (
    <section id="founder" className="founder-section section">
      <div className="container">
        <div className="founder-grid">
          <motion.div
            className="founder-identity"
            initial={{ opacity: 0, x: -34 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: .2 }}
            transition={{ duration: .75, ease: [0.22, 1, 0.36, 1] }}
          >
            <span className="kicker">05 / The founder</span>
            <div className="founder-avatar" aria-hidden="true"><span>GM</span><i /></div>
            <p className="founder-name">Ghulam Mustafa</p>
            <p className="founder-role">Founder &amp; operator, DAFTRIFY</p>
            <p className="founder-location"><MapPin size={14} /> Faisalabad, Pakistan</p>
          </motion.div>

          <motion.div
            className="founder-copy"
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: .18 }}
            transition={{ duration: .8, delay: .08, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="founder-overline"><Sparkles size={14} /> Built from the operator's side of the problem</div>
            <h2>Building DAFTRIFY<br /><i>one real workflow at a time.</i></h2>
            <p className="founder-lead">DAFTRIFY started with a practical question: can messy, time-consuming document work be made clearer and faster without losing the human judgment behind it?</p>
            <p>Ghulam Mustafa is building DAFTRIFY as a hands-on document operations studio, using AI where it creates speed and structure while keeping the final work intentional, useful and reviewable.</p>

            <div className="founder-principles">
              <div><Check size={15} /><span>AI-assisted, not blindly automated</span></div>
              <div><Check size={15} /><span>Clarity before unnecessary complexity</span></div>
              <div><Check size={15} /><span>Real work over invented credentials</span></div>
            </div>

            <a className="founder-link" href="#work">See the work <ArrowUpRight size={15} /></a>
          </motion.div>
        </div>

        <motion.div
          className="founder-bottomline"
          initial={{ opacity: 0, scaleX: .92 }}
          whileInView={{ opacity: 1, scaleX: 1 }}
          viewport={{ once: true, amount: .3 }}
          transition={{ duration: .9, ease: [0.22, 1, 0.36, 1] }}
        >
          <span>GHULAM MUSTAFA / DAFTRIFY</span>
          <span>CLARITY / SPEED / DETAIL</span>
        </motion.div>
      </div>
    </section>
  );
}
