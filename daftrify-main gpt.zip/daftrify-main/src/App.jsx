import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, useScroll, useTransform } from 'framer-motion';
import {
  ArrowDownRight, ArrowRight, ArrowUpRight, Briefcase, Check, ChevronDown, FileCheck2, FileText,
  Globe2, GraduationCap, Menu, MessageCircle, MoveUpRight, ScanSearch, ShieldCheck, Sparkles, X, Zap
} from 'lucide-react';

const WA = 'https://wa.link/9d0k3o';
const ease = [0.22, 1, 0.36, 1];

function Logo() {
  return (
    <a href="#top" className="brand" aria-label="DAFTRIFY home">
      <span className="brand-mark"><FileCheck2 size={18} /></span>
      <span>DAFTR<span className="brand-accent">IFY</span></span>
    </a>
  );
}

function MagneticButton({ children, href = WA, secondary = false }) {
  return (
    <a href={href} target={href.startsWith('http') ? '_blank' : undefined} rel={href.startsWith('http') ? 'noreferrer' : undefined} className={`magnetic-btn ${secondary ? 'secondary' : ''}`}>
      <span>{children}</span><ArrowUpRight size={15} />
    </a>
  );
}

function Nav() {
  const [open, setOpen] = useState(false);
  const [solid, setSolid] = useState(false);

  useEffect(() => {
    const f = () => setSolid(window.scrollY > 28);
    window.addEventListener('scroll', f);
    return () => window.removeEventListener('scroll', f);
  }, []);

  const links = [['Capabilities', '#capabilities'], ['Work', '#work'], ['System', '#system'], ['About', '#about']];

  return (
    <header className={`site-nav ${solid ? 'nav-solid' : ''}`}>
      <div className="nav-inner">
        <Logo />
        <nav>{links.map(([label, href]) => <a key={href} href={href}>{label}</a>)}</nav>
        <div className="nav-right"><span className="availability"><i /> Available for selected projects</span><MagneticButton>Start a project</MagneticButton></div>
        <button className="menu-btn" onClick={() => setOpen(!open)} aria-label="Open menu">{open ? <X size={19} /> : <Menu size={19} />}</button>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="mobile-menu">
            <div>{links.map(([label, href]) => <a onClick={() => setOpen(false)} key={href} href={href}>{label}<ArrowUpRight size={15} /></a>)}<MagneticButton>Start a project</MagneticButton></div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 160]);
  const opacity = useTransform(scrollYProgress, [0, 0.72], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.94]);

  return (
    <section ref={ref} id="top" className="hero">
      <div className="hero-noise" />
      <div className="hero-grid" />
      <div className="orb orb-one" />
      <div className="orb orb-two" />

      <motion.div style={{ y, opacity, scale }} className="hero-inner">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .75, ease }} className="eyebrow">
          <span className="live-dot" /> AI-assisted document studio <span className="eyebrow-line" /> 01 / 05
        </motion.div>

        <motion.h1 initial={{ opacity: 0, y: 38 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .95, delay: .06, ease }} className="hero-title">
          Messy information.<br /><em>Clear documents.</em>
        </motion.h1>

        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .8, delay: .18, ease }} className="hero-bottom">
          <p>DAFTRIFY transforms scattered requirements, notes and source material into professional, review-ready documents. Visa is where we start. The system is built for much more.</p>
          <div className="hero-actions"><MagneticButton>Bring a document problem</MagneticButton><a href="#capabilities" className="text-link">Explore the studio <ArrowDownRight size={16} /></a></div>
        </motion.div>
      </motion.div>

      <div className="hero-visual-wrap"><DocumentMachine /></div>

      <motion.div className="scroll-cue" animate={{ y: [0, 6, 0], opacity: [1, .75, 1] }} transition={{ duration: 3.4, repeat: Infinity, ease: 'easeInOut' }}>
        <span>Scroll to explore</span><i /></motion.div>
    </section>
  );
}

function DocumentMachine() {
  return (
    <div className="machine">
      <div className="machine-label"><span>DAFTRIFY / DOCUMENT LAB</span><span>LIVE SYSTEM 001</span></div>
      <div className="machine-stage">
        <motion.div initial={{ opacity: 0, rotate: -7, x: -50, y: 12, scale: .96 }} animate={{ opacity: 1, rotate: -7, x: 0, y: 0, scale: 1 }} transition={{ duration: 1.05, delay: .25, ease }} className="paper raw-paper">
          <div className="paper-top"><span>RAW INPUT</span><span>04 FILES</span></div>
          <div className="scribble s1" /><div className="scribble s2" /><div className="scribble s3" /><div className="scribble s4" /><div className="scribble s5" />
          <div className="red-note">needs structure</div>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: .78, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} transition={{ duration: .8, delay: .56, ease }} className="transform-node">
          <Sparkles size={17} /><span>STRUCTURE</span>
        </motion.div>

        <motion.div initial={{ opacity: 0, rotate: 7, x: 50, y: 12, scale: .96 }} animate={{ opacity: 1, rotate: 7, x: 0, y: 0, scale: 1 }} transition={{ duration: 1.05, delay: .42, ease }} className="paper final-paper">
          <div className="paper-top"><span>FINAL PASS</span><span className="green">READY</span></div>
          <div className="doc-heading">APPLICATION<br /><b>DOCUMENT SET</b></div>
          <div className="doc-rule" />
          <div className="doc-lines"><i /><i /><i /><i /></div>
          <div className="doc-check"><Check size={12} /> STRUCTURED</div>
        </motion.div>

        <motion.div animate={{ y: [0, -12, 0], rotate: [-1, 1, -1] }} transition={{ duration: 4.6, repeat: Infinity, ease: 'easeInOut' }} className="floating-tag tag-a"><ScanSearch size={14} /><span>Quality checked</span></motion.div>
        <motion.div animate={{ y: [0, 10, 0], rotate: [1, -1, 1] }} transition={{ duration: 4.1, repeat: Infinity, ease: 'easeInOut' }} className="floating-tag tag-b"><Zap size={14} /><span>AI-assisted</span></motion.div>
        <motion.div animate={{ x: [0, 10, 0], opacity: [.65, 1, .65] }} transition={{ duration: 5.2, repeat: Infinity, ease: 'easeInOut' }} className="floating-tag tag-c"><MoveUpRight size={14} /><span>Document flow</span></motion.div>
      </div>
      <div className="machine-footer"><span>01</span><div className="machine-progress"><i /></div><span>05</span></div>
    </div>
  );
}

const capabilities = [
  { n: '01', icon: Globe2, title: 'Visa & immigration', text: 'Application packs, SOP support, requirement mapping and document-gap organization.', tags: ['Checklists', 'SOPs', 'Gap review'] },
  { n: '02', icon: GraduationCap, title: 'Academic work', text: 'Statements, proposals, letters, research formatting and coherent application sets.', tags: ['SOPs', 'Proposals', 'Formatting'] },
  { n: '03', icon: Briefcase, title: 'Business documents', text: 'Profiles, proposals, reports, summaries and client-facing business material.', tags: ['Profiles', 'Reports', 'Proposals'] },
  { n: '04', icon: FileText, title: 'Custom document work', text: 'If it is information-heavy and document-based, we can design the workflow around it.', tags: ['Custom', 'Research', 'Operations'] },
];

function Capabilities() {
  return (
    <section id="capabilities" className="section capabilities">
      <div className="container">
        <div className="section-intro">
          <div><span className="kicker">01 / Capabilities</span><h2>One studio.<br /><i>Many document problems.</i></h2></div>
          <p>Visa documentation is the entry point, not the ceiling. DAFTRIFY is being built as a flexible document operations studio that can adapt to different people, industries and workflows.</p>
        </div>
        <div className="cap-grid">
          {capabilities.map((item, i) => (
            <motion.article key={item.n} initial={{ opacity: 0, y: 34, scale: .98 }} whileInView={{ opacity: 1, y: 0, scale: 1 }} viewport={{ once: true, amount: .14 }} transition={{ duration: .7, delay: i * .08, ease }} className={`cap-card ${i === 0 ? 'featured' : ''}`}>
              <div className="cap-top"><span className="cap-icon"><item.icon size={18} /></span><span className="cap-num">{item.n}</span></div>
              <div><h3>{item.title}</h3><p>{item.text}</p><div className="tags">{item.tags.map(t => <span key={t}>{t}</span>)}</div></div>
              <ArrowUpRight className="cap-arrow" size={18} />
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Transformation() {
  return (
    <section className="section transformation">
      <div className="container">
        <div className="transform-head">
          <div><span className="kicker">02 / The idea</span><h2>Documents are rarely<br /><i>the real problem.</i></h2></div>
          <p>The mess around them is. Missing information. Conflicting versions. Poor structure. Unclear requirements. DAFTRIFY is designed to remove that friction.</p>
        </div>
        <div className="transform-flow">
          <FlowCard label="01 / INPUT" title="Messy material" lines={['notes.docx', 'requirements.pdf', 'voice-note.txt', 'random links']} />
          <div className="flow-arrow"><span>structure</span><ArrowRight /></div>
          <FlowCard label="02 / PROCESS" title="DAFTRIFY system" lines={['Understand', 'Organize', 'Draft', 'Verify']} />
          <div className="flow-arrow"><span>deliver</span><ArrowRight /></div>
          <FlowCard label="03 / OUTPUT" title="Professional set" lines={['clear hierarchy', 'consistent details', 'review-ready', 'fit for purpose']} />
        </div>
      </div>
    </section>
  );
}

function FlowCard({ label, title, lines }) {
  return (
    <div className="flow-card">
      <span className="kicker">{label}</span>
      <h3>{title}</h3>
      <div className="flow-lines">{lines.map((x, i) => <div key={x}><span className={i === 0 ? 'active' : ''}>{i === 0 ? <FileText size={13} /> : <Check size={13} />}</span>{x}</div>)}</div>
    </div>
  );
}

const work = [
  { num: '01', type: 'CONCEPT / VISA', title: 'Application readiness system', text: 'A sample workflow that turns a loose visa requirement list into an organized application map.', accent: 'blue' },
  { num: '02', type: 'CONCEPT / ACADEMIC', title: 'Statement & evidence set', text: 'A cohesive presentation system for SOPs, supporting letters and academic material.', accent: 'cream' },
  { num: '03', type: 'CONCEPT / BUSINESS', title: 'Company profile system', text: 'A structured business-document concept for turning raw company information into a polished profile.', accent: 'mint' },
];

function Work() {
  return (
    <section id="work" className="section work">
      <div className="container">
        <div className="section-intro">
          <div><span className="kicker">03 / Selected work</span><h2>Proof of thinking,<br /><i>not fake clients.</i></h2></div>
          <p>These are concept pieces, not invented client results. The purpose is simple: show what DAFTRIFY can actually build before a client hands over the first real project.</p>
        </div>
        <div className="work-grid">
          {work.map((item, i) => (
            <motion.article key={item.num} initial={{ opacity: 0, y: 38, scale: .98 }} whileInView={{ opacity: 1, y: 0, scale: 1 }} viewport={{ once: true, amount: .12 }} transition={{ duration: .75, delay: i * .1, ease }} className="work-card">
              <div className={`work-art ${item.accent}`}>
                <div className="art-meta"><span>{item.type}</span><span>{item.num}</span></div>
                <WorkMockup index={i} />
                <span className="art-cursor"><MoveUpRight size={15} /></span>
              </div>
              <div className="work-copy"><span>{item.num} / CONCEPT</span><h3>{item.title}</h3><p>{item.text}</p></div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

function WorkMockup({ index }) {
  if (index === 0) return <div className="visa-mock"><div className="visa-left"><span>APPLICATION</span><strong>READY / 92%</strong><div className="ring">92</div></div><div className="visa-right"><i /><i /><i /><i /><div className="mock-check"><Check size={11} /> gaps surfaced</div></div></div>;
  if (index === 1) return <div className="academic-mock"><span>STATEMENT OF PURPOSE</span><b>Why this<br />programme?</b><div /><p>Motivation · experience · direction</p></div>;
  return <div className="business-mock"><div className="biz-logo">DF</div><b>COMPANY<br />PROFILE</b><span>Strategy / Services / Story</span><div className="biz-grid"><i /><i /><i /></div></div>;
}

function System() {
  const steps = [
    ['01', 'Understand', 'The real requirement, audience, purpose and deadline.'],
    ['02', 'Structure', 'Turn ambiguity into an actionable document plan.'],
    ['03', 'Build', 'Use AI for speed while keeping the output intentional.'],
    ['04', 'Verify', 'Check consistency, gaps and presentation before delivery.'],
    ['05', 'Deliver', 'A clean result designed for its actual next step.'],
  ];

  return (
    <section id="system" className="section system">
      <div className="container">
        <div className="system-top">
          <div><span className="kicker">04 / The system</span><h2>Simple enough to use.<br /><i>Serious enough to trust.</i></h2></div>
          <span className="system-stamp">DAFTRIFY<br />DOCUMENT<br />OPERATIONS</span>
        </div>
        <div className="system-list">
          {steps.map(([n, t, d], i) => (
            <motion.div key={n} initial={{ opacity: 0, x: -28 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: .18 }} transition={{ duration: .6, delay: i * .07, ease }} className="system-row">
              <span className="system-num">{n}</span><h3>{t}</h3><p>{d}</p><ArrowUpRight size={18} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="section about">
      <div className="container">
        <div className="about-grid">
          <div><span className="kicker">05 / Philosophy</span><h2>AI should remove<br /><i>friction, not judgment.</i></h2></div>
          <div className="about-copy">
            <p className="lead">DAFTRIFY is being built around a simple belief: the best document work combines machine speed with human context.</p>
            <p>AI is useful for structure, repetition, drafting and checks. It should not replace understanding the person, the requirement or the consequence of getting something wrong.</p>
            <div className="principles"><div><ShieldCheck size={17} /><span>Human review stays in the loop.</span></div><div><Zap size={17} /><span>Automation is used where it adds speed.</span></div><div><Check size={17} /><span>No invented testimonials or performance claims.</span></div></div>
          </div>
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const [open, setOpen] = useState(0);
  const items = [
    ['What can DAFTRIFY work on?', 'Visa, academic, business and custom document workflows. The common thread is information that needs to become structured, clear and professional.'],
    ['Is DAFTRIFY only for visa documentation?', 'No. Visa is the initial niche and a practical starting point. The broader direction is AI-assisted document operations across many use cases.'],
    ['Is the work fully automated?', 'No. AI can accelerate drafting and organization, but the intended workflow includes human review and judgment.'],
    ['Can you guarantee a visa, admission or business outcome?', 'No. DAFTRIFY can improve the quality and organization of documentation, but it cannot guarantee decisions made by an embassy, university or other third party.'],
    ['How do I start a project?', 'Send the requirement, deadline and whatever material already exists through WhatsApp. The scope can then be defined around the actual task.'],
  ];

  return (
    <section className="section faq">
      <div className="container narrow">
        <span className="kicker">06 / FAQ</span><h2>Questions before<br /><i>the first message.</i></h2>
        <div className="faq-list">
          {items.map(([q, a], i) => (
            <div key={q} className="faq-item">
              <button onClick={() => setOpen(open === i ? -1 : i)}><span>{q}</span><ChevronDown size={18} className={open === i ? 'rotated' : ''} /></button>
              <AnimatePresence initial={false}>{open === i && <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}><p>{a}</p></motion.div>}</AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section className="final-cta">
      <div className="cta-grid" />
      <div className="container">
        <span className="kicker">Start a project</span><h2>Bring the messy part.<br /><i>We’ll structure the rest.</i></h2><p>Tell DAFTRIFY what needs to be done. Start with the requirement, not a perfect brief.</p>
        <div className="cta-actions"><MagneticButton><MessageCircle size={16} /> Start on WhatsApp</MagneticButton><a href="#top" className="text-link">Back to top <ArrowUpRight size={15} /></a></div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer>
      <div className="container footer-inner"><Logo /><div className="footer-center"><span>AI-assisted document studio</span><span>Built for clarity / speed / detail</span></div><a href={WA} target="_blank" rel="noreferrer">WhatsApp <ArrowUpRight size={14} /></a></div>
      <div className="container footer-bottom"><span>© {new Date().getFullYear()} DAFTRIFY</span><span>Visa / Academic / Business / Custom</span></div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="app">
      <Nav />
      <main><Hero /><Capabilities /><Transformation /><Work /><System /><About /><FAQ /><FinalCTA /></main>
      <Footer />
    </div>
  );
}
