import React, { useEffect } from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import MotionLayer from './MotionLayer.jsx'
import Founder from './Founder.jsx'
import ContactNavBridge from './ContactNavBridge.jsx'
import Privacy from './Privacy.jsx'
import { WorkShowcase, ResourcesRail, DecisionLayer, RequestPanel } from './PremiumExperience.jsx'
import LeadForm from './LeadForm.jsx'
import './index.css'
import './work-motion.css'
import './readability.css'
import './lead-form.css'
import './accessibility.css'
import './privacy.css'

function PremiumMount() {
  useEffect(() => {
    const appRoot = document.querySelector('#root > div')
    const main = appRoot?.querySelector('main')
    const workSection = main?.querySelector('#work')
    if (!main || !workSection) return undefined
    main.id = 'main-content'

    const slot = document.createElement('div')
    slot.id = 'premium-experience-slot'
    workSection.insertAdjacentElement('afterend', slot)

    const premiumRoot = ReactDOM.createRoot(slot)
    premiumRoot.render(<><ResourcesRail /><WorkShowcase /><DecisionLayer /><RequestPanel /><LeadForm /></>)

    return () => {
      premiumRoot.unmount()
      slot.remove()
    }
  }, [])

  return null
}

function FounderMount() {
  useEffect(() => {
    const main = document.querySelector('#root > div main')
    const aboutSection = main?.querySelector('#about')
    if (!main || !aboutSection) return undefined

    const slot = document.createElement('div')
    slot.id = 'founder-experience-slot'
    aboutSection.insertAdjacentElement('afterend', slot)

    const founderRoot = ReactDOM.createRoot(slot)
    founderRoot.render(<Founder />)

    return () => {
      founderRoot.unmount()
      slot.remove()
    }
  }, [])

  return null
}

function PrivacyMount() {
  useEffect(() => {
    const root = document.querySelector('#root > div')
    const footer = root?.querySelector('footer')
    if (!root || !footer) return undefined

    const slot = document.createElement('div')
    slot.id = 'privacy-experience-slot'
    footer.insertAdjacentElement('beforebegin', slot)

    const privacyRoot = ReactDOM.createRoot(slot)
    privacyRoot.render(<Privacy />)

    return () => {
      privacyRoot.unmount()
      slot.remove()
    }
  }, [])

  return null
}

function Site() {
  return <>
    <App />
    <MotionLayer />
    <PremiumMount />
    <FounderMount />
    <PrivacyMount />
    <ContactNavBridge />
  </>
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Site />
  </React.StrictMode>,
)
