import React, { useMemo, useState } from 'react';
import { ArrowUpRight, Check, Clipboard, Clock3, FileText, Mail, MessageCircle, Send, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';

const WA = 'https://wa.link/9d0k3o';
const SERVICE_EMAIL = 'daftrify.services@gmail.com';
const PERSONAL_EMAIL = 'mustafasagheer.business@gmail.com';
const FORM_ENDPOINT = 'https://formsubmit.co/ajax/daftrify.services@gmail.com';

const services = [
  'Document creation',
  'Document cleanup & formatting',
  'AI-assisted research & structuring',
  'Visa / application documentation',
  'Academic documents',
  'Business documents',
  'Something else',
];

export default function LeadForm() {
  const [form, setForm] = useState({ name: '', email: '', service: '', deadline: '', material: '', details: '', website: '' });
  const [status, setStatus] = useState('idle');
  const [copied, setCopied] = useState(false);
  const [revealed, setRevealed] = useState('');

  const brief = useMemo(() => [
    'DAFTRIFY — NEW PROJECT INQUIRY',
    `Name: ${form.name || 'Not provided'}`,
    `Email: ${form.email || 'Not provided'}`,
    `Service: ${form.service || 'Not selected'}`,
    `Deadline: ${form.deadline || 'Not provided'}`,
    `Existing material: ${form.material || 'Not specified'}`,
    '',
    'Requirement:',
    form.details || 'Not provided',
  ].join('\n'), [form]);

  const update = (key) => (e) => setForm(v => ({ ...v, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    if (form.website.trim()) return;
    if (!form.service || !form.details.trim() || !form.name.trim() || !form.email.trim()) return;
    setStatus('sending');
    try {
      const response = await fetch(FORM_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          service: form.service,
          deadline: form.deadline || 'Not provided',
          existing_material: form.material || 'Not specified',
          message: form.details,
          _subject: `DAFTRIFY project inquiry — ${form.service}`,
          _replyto: form.email,
          _template: 'table',
          _honey: form.website,
        }),
      });
      const data = await response.json();
      if (!response.ok || data.success === false) throw new Error('Submission failed');
      try { await navigator.clipboard?.writeText(brief); } catch { /* optional */ }
      setCopied(true);
      setStatus('sent');
    } catch {
      setStatus('error');
    }
  };

  const reveal = (type) => setRevealed(prev => prev === type ? '' : type);
  const revealedEmail = revealed === 'services' ? SERVICE_EMAIL : PERSONAL_EMAIL;

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(revealedEmail);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch { /* optional */ }
  };

  return <section id="inquiry" className="lead-section">
    <div className="mx-auto grid max-w-7xl gap-10 px-5 sm:px-7 lg:grid-cols-[.72fr_1.28fr] lg:gap-20">
      <motion.div initial={{ opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .2 }} transition={{ duration: .7 }}>
        <p className="section-kicker">Project intake</p>
        <h2 className="mt-4 font-display text-4xl font-semibold leading-[.96] tracking-[-.055em] text-white sm:text-6xl">Give us the rough version.</h2>
        <p className="mt-6 max-w-md text-base leading-7 text-white/42">No polished brief required. A few useful details are enough to start a focused conversation.</p>
        <div className="mt-9 space-y-4">
          <div className="lead-point"><span><FileText size={16}/></span><div><strong>Requirement-first</strong><p>We clarify the outcome before building anything.</p></div></div>
          <div className="lead-point"><span><Clock3 size={16}/></span><div><strong>Deadline-aware</strong><p>Tell us when the document actually needs to be usable.</p></div></div>
          <div className="lead-point"><span><ShieldCheck size={16}/></span><div><strong>No invented claims</strong><p>No fake credentials, outcomes, clients or guarantees.</p></div></div>
        </div>

        <div className="email-contact">
          <div className="email-contact-head"><span>Prefer email?</span><span>Click to reveal</span></div>
          <div className="email-reveal-grid">
            <button type="button" className={`email-reveal ${revealed === 'services' ? 'revealed' : ''}`} onClick={() => reveal('services')}>
              <Mail size={14}/><span>{revealed === 'services' ? SERVICE_EMAIL : 'Service inquiries'}</span><ArrowUpRight size={13}/>
            </button>
            <button type="button" className={`email-reveal ${revealed === 'personal' ? 'revealed' : ''}`} onClick={() => reveal('personal')}>
              <Mail size={14}/><span>{revealed === 'personal' ? PERSONAL_EMAIL : 'Direct / founder contact'}</span><ArrowUpRight size={13}/>
            </button>
          </div>
          {revealed && <button type="button" className="copy-email" onClick={copyEmail}><Clipboard size={13}/>{copied ? 'Copied' : 'Copy revealed email'}</button>}
        </div>
      </motion.div>

      <motion.form onSubmit={submit} initial={{ opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .16 }} transition={{ duration: .7, delay: .08 }} className="lead-form">
        <div className="form-topline"><span>PROJECT INTAKE</span><span>DAFTRIFY / 001</span></div>
        <div className="grid gap-5 sm:grid-cols-2">
          <label>What should we call you?<input value={form.name} onChange={update('name')} placeholder="Your name" autoComplete="name" required /></label>
          <label>Your email<input type="email" value={form.email} onChange={update('email')} placeholder="you@example.com" autoComplete="email" required /></label>
          <label>What do you need?<select value={form.service} onChange={update('service')} required><option value="">Select a service</option>{services.map(s => <option key={s}>{s}</option>)}</select></label>
          <label>When do you need it?<input value={form.deadline} onChange={update('deadline')} placeholder="e.g. 18 August" /></label>
          <label className="sm:col-span-2">Do you already have material?<select value={form.material} onChange={update('material')}><option value="">Select one</option><option>Yes, I have files/notes</option><option>Some notes only</option><option>No, I need help from scratch</option></select></label>
        </div>
        <label className="mt-5 block">Tell us what you're trying to get done<textarea value={form.details} onChange={update('details')} required rows={7} placeholder="What is the document for? Who will read it? What do you already have? What is unclear right now?" /></label>
        <label className="honeypot" aria-hidden="true">Website<input tabIndex="-1" autoComplete="off" value={form.website} onChange={update('website')} /></label>
        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[11px] leading-5 text-white/28">No files are uploaded by this form. Share sensitive documents only after the scope is agreed.</p>
          <button type="submit" className="lead-submit" disabled={status === 'sending'}>{status === 'sending' ? 'Sending…' : status === 'sent' ? 'Inquiry sent' : 'Send inquiry'}{status === 'sent' ? <Check size={15}/> : <Send size={15}/>}</button>
        </div>
        {status === 'sent' && <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="lead-success"><div><Check size={16}/><strong>{copied ? 'Inquiry sent to DAFTRIFY.' : 'Inquiry received.'}</strong><p>The details were emailed to the service inbox. You can also continue on WhatsApp.</p></div><a href={WA} target="_blank" rel="noreferrer"><MessageCircle size={15}/> WhatsApp <ArrowUpRight size={14}/></a><button type="button" onClick={async()=>{try{await navigator.clipboard?.writeText(brief);setCopied(true)}catch{}}} aria-label="Copy inquiry"><Clipboard size={15}/></button></motion.div>}
        {status === 'error' && <div className="lead-error">The email service could not accept the submission. Please try again or use the revealed service email.</div>}
      </motion.form>
    </div>
  </section>;
}
