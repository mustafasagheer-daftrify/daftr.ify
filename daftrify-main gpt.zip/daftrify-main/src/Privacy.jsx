import React from 'react';
import { ArrowUpRight, LockKeyhole, ShieldCheck } from 'lucide-react';

export default function Privacy() {
  return (
    <section id="privacy" className="privacy-section" aria-labelledby="privacy-title">
      <div className="container privacy-grid">
        <div>
          <span className="kicker">07 / Privacy</span>
          <h2 id="privacy-title">Your information<br /><i>stays purposeful.</i></h2>
          <p className="privacy-lead">DAFTRIFY only asks for the information needed to understand a project, respond to an inquiry and deliver the requested work.</p>
        </div>
        <div className="privacy-panel">
          <div className="privacy-item"><span><ShieldCheck size={17} /></span><div><strong>What we collect</strong><p>Name, email, service, deadline, existing-material notes and the project description submitted through the intake form.</p></div></div>
          <div className="privacy-item"><span><LockKeyhole size={17} /></span><div><strong>How it is used</strong><p>To review the request, communicate with the requester and prepare or discuss the requested service. We do not sell inquiry information.</p></div></div>
          <div className="privacy-item"><span><ShieldCheck size={17} /></span><div><strong>Sensitive documents</strong><p>The intake form does not accept file uploads. Do not place passports, identity documents, financial records or other sensitive files into the message field. Share such material only after the scope and secure delivery method have been agreed.</p></div></div>
          <div className="privacy-item"><span><LockKeyhole size={17} /></span><div><strong>Third-party services</strong><p>Website hosting is provided by Vercel. Project inquiries are delivered through FormSubmit to the DAFTRIFY service inbox. Their own policies apply to data processed by those services.</p><div className="privacy-links"><a href="https://formsubmit.co/privacy" target="_blank" rel="noreferrer">FormSubmit privacy <ArrowUpRight size={13} /></a><a href="https://vercel.com/legal/privacy-policy" target="_blank" rel="noreferrer">Vercel privacy <ArrowUpRight size={13} /></a></div></div></div>
          <p className="privacy-note">Last updated: August 2026. This is a practical privacy notice for the DAFTRIFY website, not legal advice.</p>
        </div>
      </div>
    </section>
  );
}
